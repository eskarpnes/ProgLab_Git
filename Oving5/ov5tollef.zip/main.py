from image import Img
from PIL import Image
import os
import time
import random

def handle_input(input_list):
    for num,img in enumerate(input_list):
        print (num,'\t',img)
    try:
        return int(input('\n> Select an image: '))
    except:
        print ('Invalid input, giving you a random image...')
        return random.randint(0,len(input_list)-1)
        
def get_file():
    path = 'images\\'
    folder = os.listdir(path)
    selected = handle_input(folder)
    print ('\nYou selected:', folder[selected])
    return path+folder[selected]

def main():
    # selected = get_file()
    # img1 = Img(get_file())
    # img1 = Img('images\\fibonacci.jpeg')
    # img1.show()
    # img2 = Img('images\\einstein.jpeg')
    # resized = img1.resize(img2.getSize())
    # resized.show()
    # cropped = img1.cropTopLeft(500,500)
    # cropped.show()
    # cropped2 = img1.cropMiddle(300,300)
    # cropped2.show()
    # sq = img1.makeSquare()
    # sq.show()
    # rot45 = img1.rotate(45,zoom=False)
    # rot45.show()
    # zoomed = img1.zoom(5, 0.8,centre=True)
    # zoomed.show()
    # fadedmatrix = img1.fadeMat(fade=20)
    # fadedmatrix.show()
    # blended = img1.blend(img2,0.7)
    # blended.show()
    # blendmatrix = img1.blendMat(img2)
    # blendmatrix.show()
    # gray = img1.gray()
    # gray.show()
    # bw = img1.bw()
    # bw.show()
    # sharp = img1.sharpen(factor=0.0)  # blur = 0.0, sharp = 2.0
    # sharp.show()
    # test = img1.fadeMat(3)
    # test.show()
    # m = img1.keepMax()
    # m.show()
    # im = Img()
    # scr = im.screenshot()
    # im.setImage(scr,name='screenshot')
    # im.show()
    # z = im.zoom(center=True)
    # z.show()
    # blur = im.blurMat()
    # blur.show()
    # scr_crop = im.square(500) # makes a square and resizes to 500
    # scr_crop.show()
    # edge = img1.edge()
    # edge.show()
    # emboss = img1.emboss()
    # emboss.show()
    im = Img()
    im.whatup()


main()

# def other():
    # opens the einstein pic in the background
    # im = Image.open(path+"einstein.jpeg") 
    # empty image to store different once on:
    # empty = Image.new('RGB', (400,400))
    # im.thumbnail((100,100))
    # for img in img_folder:
    # for i in range(0,500,100):
        # for j in range(0,500,100):
            # im = Image.eval(im, lambda x: x+(i/20+j/40))
            # empty.paste(im, (i,j))
    # empty.show()
    